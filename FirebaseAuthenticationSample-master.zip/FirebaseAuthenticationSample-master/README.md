# FirebaseAuthenticationSample

FirebaseAuthenticationSample helps you to Authenticate User to your Android app.

FirebaseAuthenticationSample contains 3 types of authentication
- Password Authentication
- Google Sign In Authentication
- Facebook Authentication

<b>USAGE:</b>

Clone or download repository & import it into your Android Studio.

<b>Requirements:</b>

1. Facebook App ID & Facebook Login Protocol Scheme (For Facebook Integration)
2. Server Web CLient ID. (For authenticate users with firebase server)




